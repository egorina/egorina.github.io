if (!require("pacman")) install.packages("pacman")
if (!require("pacman")) install.packages("pacman")
p_load(RSelenium)
p_load(rvest, stringfix) # Packages for scraping
p_load(data.table, dplyr, tidyr, stringr, methods, curl, R.utils) # Packages for text mining
`%+%` <- function(x,y){ paste0(x, y)}
clean_up <- function (x){
  # x <- gsub("[[:punct:]]"," ", x)
  x <- gsub("\r", "", x)
  x <- gsub("\n", "", x)
  x <- gsub("\\s+", " ", x)
  x <- gsub("^\\s+", "", x)
  x <- gsub("\\s+$", "", x)
  # x <- gsub("[ ]", "+", x)
  return(x)
}
## ------------------------------------------------------------------------
# https://reyestr.court.gov.ua/Review/100308875
# crimea docs 1516548
###

url.start <- 'https://reyestr.court.gov.ua/'

rD <- rsDriver(browser="firefox", port=4545L, verbose=F)
remDr <- rD[["client"]]
remDr$navigate(url.start)

html.vector <- c()

path.to.save <- "crimea-cases-pages.csv"
path.to.save.list <- "crimea-cases-pages-list.csv"
path.to.save.covs <- "crimea-cases-immediate-covariates.csv"

pages <- 281:499
page.i <- 1
for(page.i in pages){
  page_list <- unlist(remDr$getCurrentUrl())
  page_list <- gsub('https://reyestr.court.gov.ua/Page/', "", page.i)
  print(page_list)
  Sys.sleep(6) 
  html.i <- remDr$getPageSource()[[1]]
  html.i.page <- read_html(html.i)
  html.vector.i <- html.i.page %>% html_nodes(".doc_text2") %>% html_text()
  # Other immediate covariates
  
  VRType.i <- html.i.page %>% html_nodes(".VRType") %>% html_text()
    VRType.i <- clean_up(VRType.i)
  RegDate.i <- html.i.page %>% html_nodes(".RegDate") %>% html_text()
    RegDate.i <- clean_up(RegDate.i)
  LawDate.i <- html.i.page %>% html_nodes(".LawDate") %>% html_text()
    LawDate.i <- clean_up(LawDate.i)
  CSType.i <- html.i.page %>% html_nodes(".CSType") %>% html_text()
    CSType.i <- clean_up(CSType.i)
  CaseNumber.i <- html.i.page %>% html_nodes(".CaseNumber") %>% html_text()
    CaseNumber.i <- clean_up(CaseNumber.i)  
  CourtName.i <- html.i.page %>% html_nodes(".CourtName") %>% html_text()
    CourtName.i <- clean_up(CourtName.i)  
  ChairmenName.i <- html.i.page %>% html_nodes(".ChairmenName") %>% html_text()
    ChairmenName.i <- clean_up(ChairmenName.i)   

# Write Results
  write(html.vector.i,file=path.to.save,append=TRUE)
  write(page_list,file = path.to.save.list,append=TRUE)
  
  d.i <- data.table(number = html.vector.i, VRType = VRType.i,CSType = CSType.i,
                    RegDate = RegDate.i, LawDate = LawDate.i,
                    CaseNumber = CaseNumber.i, CourtName = CourtName.i,
                    ChairmenName = ChairmenName.i
                    )
  fwrite(d.i, path.to.save.covs, append = T, col.names = F, sep = "\t")

# Next page
  webElem <- remDr$findElement(using = "css selector", ".enButton:nth-child(16)")
  webElem$clickElement()  
}
